WELCOME TO Raspberry Pi!
========================

Seems like you downloaded this tar to get familiar with the BASH
to get able to efficiently work on your raspberry pi!
Good progress!

